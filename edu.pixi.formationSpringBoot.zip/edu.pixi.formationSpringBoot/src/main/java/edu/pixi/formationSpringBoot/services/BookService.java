package edu.pixi.formationSpringBoot.services;

import java.util.List;

import edu.pixi.formationSpringBoot.entities.Book;
import edu.pixi.formationSpringBoot.entities.User;

public interface BookService {
	//methode CRUD basiques
	public List<Book> getAllBook();
	public Book findBookById(Long id);
	public Book createBook(Book book);
	public void deleteBook(Long id);
	public Book updateBook(Book book);
		
	//methodes CRUD avancées
	public List<Book> findBookByTitle(String title);
	public List<Book> findBookByTitleAndAuthor(String title,String author);
	public List<Book> findBookByTitleAndUser(String title,User user);
}
