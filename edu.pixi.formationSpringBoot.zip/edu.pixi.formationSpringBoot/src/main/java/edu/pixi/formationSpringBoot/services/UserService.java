package edu.pixi.formationSpringBoot.services;

import java.util.List;

import edu.pixi.formationSpringBoot.entities.User;

public interface UserService {
	//methode CRUD basiques
	public List<User> getAllUser();
	public User findUserById(Long id);
	public User createUser(User user);
	public void deleteUser(Long id);
	public User updateUser(User user);
	
	//methodes CRUD avancées
	public List<User> findByFirstName(String firstName);
	public List<User>findByFirstNameAndLastName(String firstName,String lastName);

}
