package edu.pixi.formationSpringBoot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.springframework.boot.SpringApplication;

import org.springframework.boot.autoconfigure.SpringBootApplication;

import edu.pixi.formationSpringBoot.services.BookServiceImp;



@SpringBootApplication

public class Application {
	static BookServiceImp book = new BookServiceImp();
	public static void main(String[] args) throws ParseException {
		SpringApplication.run(Application.class, args);
		
		
		String str1 = "2020-11-28";
		Date d1 = new SimpleDateFormat("yyyy-MM-dd").parse(str1);
		System.out.println(d1);
		String str2 = "2020-11-29";
		Date d2 = new SimpleDateFormat("yyyy-MM-dd").parse(str2);
		book.inInfraction(d1,d2);
	}

}
