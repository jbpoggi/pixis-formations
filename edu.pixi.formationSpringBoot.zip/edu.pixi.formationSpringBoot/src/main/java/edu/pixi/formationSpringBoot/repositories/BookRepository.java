package edu.pixi.formationSpringBoot.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.pixi.formationSpringBoot.entities.Book;
import edu.pixi.formationSpringBoot.entities.User;

@Repository
public interface BookRepository extends JpaRepository<Book,Long>{
	public List<Book> findBookByTitle(String title);
	public List<Book> findBookByTitleAndAuthor(String title,String author);
	public List<Book> findBookByTitleAndUser(String title,User user);
	
}
