package edu.pixi.formationSpringBoot.entities;

import java.io.Serializable;
import java.sql.Date;




import jakarta.persistence.Entity;

import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;



@Entity

public class Book implements Serializable{
	private static final long serialVersionUID = 2L;
	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	private Long id;
	private String title;
	private String author;
	@ManyToOne
	@JoinColumn(name="user_id")
	private User user;
	
	private boolean in_infraction;
	private Date loanDate;
	public Book() {
		
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public boolean isIn_infraction() {
		return in_infraction;
	}
	public void setIn_infraction(boolean in_infraction) {
		this.in_infraction = in_infraction;
	}
	public Date getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(Date loanDate) {
		this.loanDate = loanDate;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	
}
