package edu.pixi.formationSpringBoot.controllers;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.pixi.formationSpringBoot.entities.User;
import edu.pixi.formationSpringBoot.services.UserService;

@RestController
@RequestMapping("/user") //localhost:8080/user
public class userController {
	@Autowired
	public UserService userService;
	@GetMapping(path="/findUserById/{id}")//localhost:8080/user/findUserById/id OK
	public User findUserById(@PathVariable Long id) {
		return userService.findUserById(id);
	}
	
	@GetMapping(path="/getAllUsers")//localhost:8080/user/getAllUsers OK
	public List<User> getAllUsers() {
		return userService.getAllUser();
		//return "all users are return";
	}
	@PutMapping(path="/updateUser")//localhost:8080/user/updateUser OK
	public User updateUser(@RequestBody User user) {
		return userService.updateUser(user);
	}
	
	@PostMapping(path="/createUser")//localhost:8080/user/createUser OK
	public User createUser(@RequestBody User user) {
		return userService.createUser(user);
	}
	@DeleteMapping(path="/deleteUser/{id}")//localhost:8080/user/deleteUser/id OK
	public void deletelUser(@PathVariable long id) {
		userService.deleteUser(id);;
	}
	@GetMapping(path="/findByFirstName/{firstName}")//localhost:8080/user/findByFirstName/{firstName}
	public List<User> findByFirstName(@PathVariable String firstName) {
		return userService.findByFirstName(firstName);
		
	}
	@GetMapping(path="/findByFirstNameAndLastName/{firstName}/{lastName}")//localhost:8080/user/findByFirstNameAndLastName/{firstName}/{lastName}
	public List<User> findByFirstNameAndLastName(@PathVariable String firstName,@PathVariable String lastName) {
		return userService.findByFirstNameAndLastName(firstName,lastName);
		
	}
	@GetMapping(path="/accueuil")//localhost:8080/user/accueuil
	public String afficheJSP(Model modele) {
		modele.addAttribute("now", new Date());
	    return "accueil";
		
	}
	
}
