package edu.pixi.formationSpringBoot.services;


import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.pixi.formationSpringBoot.entities.User;
import edu.pixi.formationSpringBoot.repositories.UserRepository;

@Service//élement de la couche métier
public class UserServiceImp implements UserService{
	@Autowired//ici on utilise Iot
	private UserRepository userRepository;

	@Override
	public List<User> getAllUser() {
		return userRepository.findAll();
		
	}

	@Override
	public User createUser(User user) {
		return userRepository.save(user);
	
	}

	@Override
	public User updateUser(User user) {
		Optional<User> optionalUser= userRepository.findById(user.getId());
		if(optionalUser.isEmpty()) {
			return null;
		}
		else {
			return userRepository.save(user);
		}
		
	}

	@Override
	public User findUserById(Long id) {
		Optional<User> optionalUser= userRepository.findById(id);
		if(optionalUser.isEmpty()) {
			return null;
		}
		else {
			return optionalUser.get();
		}
		
	}

	@Override
	public void deleteUser(Long id) {
		userRepository.deleteById(id);
		
	}
	@Override
	public List<User> findByFirstName(String firstName) {
		return userRepository.findByFirstName(firstName);
		
	}
	@Override
	public List<User> findByFirstNameAndLastName(String firstName,String lastName){
		return userRepository.findByFirstNameAndLastName(firstName, lastName);
	}

}
