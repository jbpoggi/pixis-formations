package edu.pixi.formationSpringBoot.services;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.pixi.formationSpringBoot.entities.Book;
import edu.pixi.formationSpringBoot.entities.User;
import edu.pixi.formationSpringBoot.repositories.BookRepository;

@Service//élement de la couche métier
public class  BookServiceImp implements BookService{
	
	@Autowired//ici on utilise Iot
	private BookRepository bookRepository;
	@Override
	public List<Book> getAllBook() {
		return bookRepository.findAll();
		
	}

	@Override
	public Book findBookById(Long id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Book createBook(Book book) {
		return bookRepository.save(book);
		
	}

	@Override
	public void deleteBook(Long id) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public Book updateBook(Book book) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> findBookByTitle(String title) {
		return bookRepository.findBookByTitle(title);
	}

	@Override
	public List<Book> findBookByTitleAndAuthor(String title, String author) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Book> findBookByTitleAndUser(String title, User user) {
		// TODO Auto-generated method stub
		return bookRepository.findBookByTitleAndUser(title,user);
	}
	public boolean inInfraction(Date loanDate,Date verificationDate) {
		boolean inInfraction=false;
		 String pattern = "yyyy-MM-dd";
	     SimpleDateFormat sdf = new SimpleDateFormat(pattern);
	     long laps = verificationDate.getTime() - loanDate.getTime();
         long diff = TimeUnit.MICROSECONDS.convert(laps, TimeUnit.DAYS);
         System.out.println("l'écart est de : "+diff+" jours");
	     if (diff>14) {
	    	 inInfraction=true;
	     }
	     else {
	    	 inInfraction =false;
	     }
		return inInfraction;
	}
	/*@Override
	public void reserveBook(String title) {
		// TODO Auto-generated method stub
		
	}*/

}
