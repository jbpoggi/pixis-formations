package edu.pixi.formationSpringBoot.controllers;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import edu.pixi.formationSpringBoot.entities.Book;
import edu.pixi.formationSpringBoot.entities.User;
import edu.pixi.formationSpringBoot.services.BookService;


@RestController
@RequestMapping("/book")//localhost:8080/book
public class BookController {
	@Autowired
	public BookService bookService;
	
	@GetMapping(path="/getAllBook")//localhost:8080/book/getAllBook OK
	public List<Book> getAllBook() {
		return bookService.getAllBook();
		
	}
	@GetMapping(path="/reserveBook/{title}")//localhost:8080/book/reserveBook/{title}  OK
	public String reserveBook(@PathVariable String title) {
		List<Book> requestResult = bookService.findBookByTitle(title);
		if (requestResult==null) {
			System.out.println("vide");
			return title;
		}
		else {
			System.out.println(requestResult.size());
			
			for (int i=0;i<requestResult.size();i++) {
				System.out.println(requestResult.get(i).getLoanDate());
			}
			return "recherche de "+title;
		}
		
	}
	@PostMapping(path="/createBook")//localhost:8080/book/createBook OK
	public Book createBook(@RequestBody Book book) {
		return bookService.createBook(book);
	}
	@GetMapping(path="/recherche")//localhost:8080/book/recherche
	public List<Book> findAvailableBook(String title,User user){
		return bookService.findBookByTitleAndUser(title, user);
		
	}
}
